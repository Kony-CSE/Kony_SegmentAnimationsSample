function AS_Button_078e0e3e415944c1b39b66b868999034(eventobject) {
    setAnimation("translate")
}