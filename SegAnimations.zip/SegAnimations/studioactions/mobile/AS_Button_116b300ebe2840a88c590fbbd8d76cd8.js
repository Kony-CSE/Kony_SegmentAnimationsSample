function AS_Button_116b300ebe2840a88c590fbbd8d76cd8(eventobject) {
    setAnimation("scale")
}