function AS_Button_68a5ac27529646d6bea90ccf4410b3f6(eventobject) {
    setAnimation("translate")
}