function AS_Button_b222292d25f7451a8743c87802dec59d(eventobject, context) {
    deleteRecordwithAnimation()
}