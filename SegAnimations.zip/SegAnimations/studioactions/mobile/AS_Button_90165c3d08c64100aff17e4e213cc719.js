function AS_Button_90165c3d08c64100aff17e4e213cc719(eventobject) {
    setOperations("Remove");
}