function AS_Button_4aba58ec64214c88870c5124cdf28cc0(eventobject) {
    setAnimation("rotate");
}