function AS_Button_77d1e401bf5b47c9a1dfa8c65aeb5e87(eventobject) {
    setAnimation("scale")
}