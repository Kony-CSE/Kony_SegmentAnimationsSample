function AS_Button_322e9e3b9a2b4938a0a31c70dbe79ac1(eventobject) {
    setAnimation("rotate");
}