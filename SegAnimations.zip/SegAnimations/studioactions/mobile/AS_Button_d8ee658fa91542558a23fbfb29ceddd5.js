function AS_Button_d8ee658fa91542558a23fbfb29ceddd5(eventobject) {
    setAnimation("rotate");
}