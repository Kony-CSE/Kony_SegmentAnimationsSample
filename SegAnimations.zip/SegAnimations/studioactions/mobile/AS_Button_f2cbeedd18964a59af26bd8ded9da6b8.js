function AS_Button_f2cbeedd18964a59af26bd8ded9da6b8(eventobject) {
    setOperations("Replace");
}