function AS_Button_b441c7e79fec4798a19a8beee7404fc0(eventobject) {
    setOperations("Add");
}