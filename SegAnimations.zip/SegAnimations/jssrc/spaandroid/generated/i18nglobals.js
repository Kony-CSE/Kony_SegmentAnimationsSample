kony.globals["appid"] = "SegGestures";
kony.globals["locales"] = [];