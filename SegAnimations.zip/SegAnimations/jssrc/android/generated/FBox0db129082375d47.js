function initializeFBox0db129082375d47() {
    FBox0db129082375d47 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "25%",
        "id": "FBox0db129082375d47",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "width": "100%"
    }, {}, {});
    FBox0db129082375d47.setDefaultUnit(kony.flex.DP);
    FBox0db129082375d47.add();
}