
function SegGesturespostappinit_seq0(params){

setGestures.call(this);

};

